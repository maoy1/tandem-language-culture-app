reqDetails.Width
